package pl.robertmielczarek.trainer112

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var progress: ProgressBar
    private lateinit var scenario: Spinner
    private lateinit var answer: EditText
    private lateinit var callButton: Button
    private lateinit var speakButton: Button
    private lateinit var sendButton: Button

    private var start = 0L
    private var step = 0
    private var score = 0
    private var active = false
    private var ttsReady = false

    private val steps = listOf(
        "Proszę spokojnie powiedzieć, co się stało.",
        "Proszę podać dokładne miejsce zdarzenia.",
        "Czy miejsce jest bezpieczne dla Pana i poszkodowanego?",
        "Czy poszkodowany reaguje na głos lub dotyk?",
        "Czy poszkodowany oddycha prawidłowo?",
        "Ilu jest poszkodowanych?",
        "Czy ktoś może rozpocząć uciskanie klatki piersiowej?",
        "Czy w pobliżu znajduje się AED?",
        "Proszę przynieść i włączyć AED. Czy jest już gotowe?",
        "Proszę kontynuować RKO i wykonywać polecenia AED."
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun textView(text: String, size: Float, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun styleButton(
        label: String,
        bgColor: Int,
        textSize: Float = 17f,
        action: () -> Unit
    ): Button = Button(this).apply {
        text = label
        this.textSize = textSize
        setTextColor(Color.WHITE)
        setAllCaps(false)
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setBackgroundColor(bgColor)
        minHeight = 0
        minWidth = 0
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply {
            setMargins(dp(5), dp(4), dp(5), dp(4))
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(5), dp(12), dp(7))
            setBackgroundColor(Color.rgb(4, 7, 11))
        }

        // Header — deliberately large and readable on a tablet.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = textView("☎  112 TRAINER 3.0", 27f)
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        title.gravity = Gravity.CENTER
        header.addView(title, LinearLayout.LayoutParams(0, dp(58), 2.2f))

        status = textView("●  GOTOWY DO ĆWICZENIA", 17f, Color.rgb(70, 230, 125))
        status.gravity = Gravity.CENTER
        header.addView(status, LinearLayout.LayoutParams(0, dp(58), 1.5f))
        root.addView(header)

        // Scenario + timer
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scenario = Spinner(this).apply {
            val names = arrayOf("NZK + AED", "Wypadek drogowy", "Silne krwawienie", "Zadławienie", "Pożar")
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
        }
        top.addView(scenario, LinearLayout.LayoutParams(0, dp(54), 1.7f))

        timer = textView("00:00", 27f)
        timer.setTypeface(null, android.graphics.Typeface.BOLD)
        timer.gravity = Gravity.CENTER
        top.addView(timer, LinearLayout.LayoutParams(0, dp(54), 0.8f))

        val mode = textView("●  INSTRUKTOR", 17f, Color.rgb(75, 235, 125))
        mode.gravity = Gravity.CENTER
        top.addView(mode, LinearLayout.LayoutParams(0, dp(54), 1.1f))
        root.addView(top)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = steps.size
            progress = 0
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(7)))

        // Operator prompt.
        val prompt = textView("Nowe ćwiczenie. Naciśnij 112.", 19f)
        prompt.setPadding(dp(12), dp(5), dp(12), dp(5))
        prompt.setBackgroundColor(Color.rgb(20, 26, 34))
        root.addView(prompt, lp(-1, dp(50)))

        // Conversation area gets flexible space so bottom controls are never clipped.
        log = textView("Symulator gotowy. Wybierz scenariusz i naciśnij 112.", 17f)
        log.gravity = Gravity.TOP
        log.setPadding(dp(14), dp(8), dp(14), dp(8))
        log.setBackgroundColor(Color.rgb(10, 15, 21))
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(log)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        answer = EditText(this).apply {
            hint = "Odpowiedź kursanta…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            textSize = 17f
            setSingleLine(true)
            setPadding(dp(12), 0, dp(12), 0)
        }
        root.addView(answer, lp(-1, dp(48)))

        // Main action row — large, high contrast.
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        callButton = styleButton("☎  112  ROZPOCZNIJ", Color.rgb(220, 30, 35), 19f) { startCall() }
        speakButton = styleButton("🎙  MÓW", Color.rgb(30, 105, 220), 19f) { listen() }
        sendButton = styleButton("▶  WYŚLIJ", Color.rgb(0, 175, 85), 19f) { submit(answer.text.toString()) }
        actions.addView(callButton, lp(0, dp(58), 1f))
        actions.addView(speakButton, lp(0, dp(58), 1f))
        actions.addView(sendButton, lp(0, dp(58), 1f))
        root.addView(actions)

        // Bottom navigation — intentionally large enough to be easily tapped.
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val reset = styleButton("↻  NOWE ĆWICZENIE", Color.rgb(55, 64, 78), 16f) { reset() }
        val report = styleButton("▣  RAPORT", Color.rgb(55, 64, 78), 16f) { report() }
        val info = styleButton("⚙  USTAWIENIA", Color.rgb(55, 64, 78), 16f) {
            toast("Ustawienia: tryb instruktora aktywny.")
        }
        bottom.addView(reset, lp(0, dp(48), 1f))
        bottom.addView(report, lp(0, dp(48), 1f))
        bottom.addView(info, lp(0, dp(48), 1f))
        root.addView(bottom)

        setContentView(root)
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("pl", "PL"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            tts.setSpeechRate(0.88f)
            tts.setPitch(0.96f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {}
                override fun onError(id: String?) {}
            })
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        // Stop any previous utterance before starting a complete new operator message.
        tts.stop()
        val params = android.os.Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "operator_${SystemClock.uptimeMillis()}")
    }

    private fun startCall() {
        if (active) return
        active = true
        start = SystemClock.elapsedRealtime()
        step = 0
        score = 0
        status.text = "●  POŁĄCZENIE Z OPERATOREM 112 — SYMULACJA"
        callButton.text = "☎  POŁĄCZENIE AKTYWNE"
        add("☎ 112: Dzień dobry. Centrum Powiadamiania Ratunkowego. Proszę spokojnie odpowiadać na moje pytania.")
        speak("Dzień dobry. Centrum Powiadamiania Ratunkowego. Proszę spokojnie odpowiadać na moje pytania.")
        android.os.Handler().postDelayed({ ask() }, 2200)
    }

    private fun ask() {
        if (!active) return
        val q = steps[step]
        add("👨‍💼 OPERATOR: $q")
        speak(q)
        progress.progress = step + 1
    }

    private fun submit(raw: String) {
        if (!active || raw.isBlank()) return
        val a = raw.trim()
        answer.setText("")
        add("👤 KURSANT: $a")
        evaluate(a.lowercase(Locale("pl", "PL")))
    }

    private fun evaluate(a: String) {
        val expected = when (step) {
            0 -> listOf("nieprzytom", "leży", "wypad", "nie oddych")
            1 -> listOf("ulic", "adres", "rusz", "miejsc")
            2 -> listOf("bezpiecz", "tak")
            3 -> listOf("nie reag", "nieprzytom")
            4 -> listOf("nie oddych", "nieprawidł", "brak odde")
            5 -> listOf("jed", "1")
            6 -> listOf("ucisk", "rko", "robi")
            7 -> listOf("aed", "defib")
            8 -> listOf("włącz", "gotow", "jest")
            9 -> listOf("ucisk", "rko", "aed")
            else -> emptyList()
        }

        if (expected.any { a.contains(it) }) {
            score++
            add("✓ OPERATOR: Dobrze. Odpowiedź została przyjęta.")
        } else {
            add("ℹ OPERATOR: Przyjmuję informację. W razie potrzeby dopytam.")
        }

        if (step < steps.lastIndex) {
            step++
            android.os.Handler().postDelayed({ ask() }, 1100)
        } else {
            finishCall()
        }
    }

    private fun finishCall() {
        active = false
        progress.progress = steps.size
        callButton.text = "☎  112  ROZPOCZNIJ"
        val pct = (score.toDouble() / steps.size * 100).toInt()
        val grade = when {
            pct >= 85 -> "BARDZO DOBRZE"
            pct >= 65 -> "DOBRZE"
            pct >= 45 -> "DO POPRAWY"
            else -> "WYMAGA TRENINGU"
        }
        status.text = "●  ĆWICZENIE ZAKOŃCZONE — $grade"
        val msg = "Zgłoszenie przyjęte. W prawdziwym zdarzeniu zespół ratowniczy zostałby zadysponowany. To była wyłącznie symulacja szkoleniowa."
        add("👨‍💼 OPERATOR: $msg\n\nWynik: $score/${steps.size} — $pct% — $grade")
        speak(msg)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Rozpoznawanie mowy jest niedostępne.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "🎙  SŁUCHAM KURSANTA…" }
            override fun onResults(r: Bundle?) {
                val s = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                status.text = "●  GOTOWY"
                if (s.isNotBlank()) submit(s)
            }
            override fun onError(e: Int) {
                status.text = if (active) "●  POŁĄCZENIE AKTYWNE" else "●  GOTOWY"
                toast("Nie udało się rozpoznać mowy. Spróbuj ponownie.")
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pl-PL")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Powiedz odpowiedź do operatora 112")
        }
        recognizer!!.startListening(i)
    }

    private fun report() {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val txt = "112 TRAINER 3.1\nRaport szkoleniowy\nData: $now\nScenariusz: ${scenario.selectedItem}\nWynik: $score/${steps.size}\n\nAplikacja jest symulatorem i nie wykonuje prawdziwych połączeń z numerem 112."
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Raport 112 Trainer")
            putExtra(Intent.EXTRA_TEXT, txt)
        }
        startActivity(Intent.createChooser(i, "Udostępnij raport"))
    }

    private fun reset() {
        tts.stop()
        active = false
        step = 0
        score = 0
        progress.progress = 0
        status.text = "●  GOTOWY DO ĆWICZENIA"
        timer.text = "00:00"
        callButton.text = "☎  112  ROZPOCZNIJ"
        log.text = "Nowe ćwiczenie. Naciśnij 112."
        answer.setText("")
    }

    private fun add(s: String) {
        log.append("\n\n$s")
    }

    private fun toast(s: String) =
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
