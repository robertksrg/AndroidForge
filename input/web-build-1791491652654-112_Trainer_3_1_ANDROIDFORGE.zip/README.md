# 112 TRAINER 3.1

Tablet-first emergency call training simulator. Landscape UI with large controls, improved TTS handling, and clearer operator/course interaction.

Training simulator only — never makes a real 112 call.
