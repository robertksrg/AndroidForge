package pl.robertmielczarek.trainer112

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var progress: ProgressBar
    private lateinit var scenario: Spinner
    private lateinit var answer: EditText
    private lateinit var callButton: Button
    private lateinit var speakButton: Button
    private lateinit var sendButton: Button
    private val handler = Handler(Looper.getMainLooper())

    private var startedAt = 0L
    private var active = false
    private var ttsReady = false
    private var awaitingInitialReport = false
    private var currentQuestion = 0
    private var score = 0
    private var path = listOf<String>()
    private var pathName = "NZK + AED"
    private var currentPrompt = "Nowe ćwiczenie. Naciśnij duży przycisk 112."

    private val commonLocation = "Proszę podać dokładne miejsce zdarzenia: miejscowość, ulicę, numer budynku lub charakterystyczny punkt."
    private val commonSafety = "Czy miejsce zdarzenia jest bezpieczne dla Pana i poszkodowanego?"
    private val commonCount = "Ilu jest poszkodowanych?"
    private val nzkPath = listOf(
        "Czy poszkodowany reaguje, gdy Pan do niego mówi i delikatnie dotyka jego ramion?",
        "Czy poszkodowany oddycha prawidłowo? Proszę oceniać oddech nie dłużej niż 10 sekund.",
        "Proszę włączyć telefon na głośnik. Czy jest ktoś, kto może rozpocząć uciskanie klatki piersiowej?",
        "Proszę uciskać środek klatki piersiowej mocno i szybko, w tempie 100–120 uciśnięć na minutę. Czy ktoś przynosi AED?",
        "Proszę włączyć AED i wykonywać jego polecenia. Podczas analizy i wyładowania nikt nie może dotykać poszkodowanego. Czy AED jest już włączone?"
    )
    private val accidentPath = listOf(
        "Czy miejsce wypadku jest bezpieczne? Czy grozi pożar, ruch pojazdów lub inne niebezpieczeństwo?",
        "Ile osób zostało poszkodowanych i czy ktoś jest uwięziony w pojeździe?",
        "Czy któryś z poszkodowanych jest nieprzytomny albo ma poważne trudności z oddychaniem?",
        "Czy występuje silne krwawienie? Jeśli tak, proszę mocno uciskać ranę czystym materiałem, jeśli można to zrobić bezpiecznie.",
        "Proszę pozostać przy poszkodowanych i wykonywać polecenia. Czy może Pan wskazać ratownikom miejsce wypadku?"
    )
    private val bleedingPath = listOf(
        "Gdzie znajduje się rana i czy krwawienie jest silne lub pulsujące?",
        "Proszę mocno i nieprzerwanie uciskać ranę czystym materiałem. Czy może Pan bezpiecznie utrzymywać ucisk?",
        "Czy poszkodowany jest przytomny i oddycha prawidłowo?",
        "Czy w ranie znajduje się wbity przedmiot? Proszę go nie wyciągać.",
        "Proszę nadal uciskać ranę i nie rozłączać się. Czy ktoś może otworzyć drzwi lub wskazać ratownikom drogę?"
    )
    private val chokingPath = listOf(
        "Czy poszkodowany może mówić, oddychać lub skutecznie kaszleć?",
        "Jeśli nie może oddychać ani kaszleć skutecznie, proszę zastosować się do moich wskazówek dotyczących pierwszej pomocy. Czy jest przytomny?",
        "Czy poszkodowany traci przytomność lub przestaje oddychać prawidłowo?",
        "Czy ktoś jest obok, aby pomóc i otworzyć drzwi ratownikom?",
        "Proszę kontynuować działania zgodnie z instrukcjami i informować mnie o każdej zmianie."
    )
    private val firePath = listOf(
        "Czy wszyscy są już poza budynkiem? Proszę nie wracać do środka.",
        "Czy ktoś może być uwięziony w środku lub potrzebuje pomocy medycznej?",
        "Czy występuje dym, wyciek gazu albo ryzyko wybuchu?",
        "Proszę oddalić się od zagrożenia i nie narażać siebie. Czy podany adres jest dokładny?",
        "Proszę pozostać w bezpiecznym miejscu i wskazać służbom dojazd."
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun textView(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
    }
    private fun button(label: String, color: Int, size: Float, action: () -> Unit) = Button(this).apply {
        text = label; textSize = size; setTextColor(Color.WHITE); isAllCaps = false
        setPadding(dp(8), dp(4), dp(8), dp(4)); setBackgroundColor(color)
        minHeight = 0; minWidth = 0; stateListAnimator = null
        setOnClickListener { action() }
    }
    private fun params(w: Int, h: Int, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(5), dp(4), dp(5), dp(4)) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(8))
            setBackgroundColor(Color.rgb(4, 8, 13))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = textView("☎  112 TRAINER 3.2", 27f).apply { setTypeface(null, 1); gravity = Gravity.CENTER }
        header.addView(title, LinearLayout.LayoutParams(0, dp(52), 2f))
        status = textView("●  GOTOWY DO ĆWICZENIA", 17f, Color.rgb(60, 230, 125)).apply { gravity = Gravity.CENTER }
        header.addView(status, LinearLayout.LayoutParams(0, dp(52), 1.5f))
        root.addView(header)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        scenario = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("NZK + AED", "Wypadek drogowy", "Silne krwawienie", "Zadławienie", "Pożar"))
        }
        top.addView(scenario, LinearLayout.LayoutParams(0, dp(48), 1.5f))
        timer = textView("00:00", 26f).apply { gravity = Gravity.CENTER; setTypeface(null, 1) }
        top.addView(timer, LinearLayout.LayoutParams(0, dp(48), 0.7f))
        val instructor = textView("●  INSTRUKTOR", 17f, Color.rgb(60, 230, 125)).apply { gravity = Gravity.CENTER }
        top.addView(instructor, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(top)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 6; progress = 0 }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(6)))

        val prompt = textView("Operator najpierw wysłucha zgłoszenia.", 20f).apply {
            setPadding(dp(14), dp(6), dp(14), dp(6)); setBackgroundColor(Color.rgb(18, 28, 39))
        }
        root.addView(prompt, params(-1, dp(48)))

        log = textView("Symulator gotowy. Wybierz scenariusz i naciśnij duży przycisk 112.", 17f).apply {
            gravity = Gravity.TOP; setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.rgb(8, 15, 23))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        answer = EditText(this).apply {
            hint = "Opisz sytuację lub wpisz odpowiedź…"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 18f
            setSingleLine(true); setPadding(dp(12), 0, dp(12), 0)
        }
        root.addView(answer, params(-1, dp(48)))

        // The call button is deliberately central and much larger than all other controls.
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        speakButton = button("🎙  MÓW", Color.rgb(24, 95, 190), 19f) { listen() }
        actions.addView(speakButton, params(0, dp(64), 0.8f))
        callButton = button("☎\n112\nROZPOCZNIJ POŁĄCZENIE", Color.rgb(220, 30, 35), 24f) {
            if (active) toast("Ćwiczenie już trwa. Powiedz zgłoszenie przyciskiem MÓW lub wpisz je poniżej.") else startCall()
        }
        callButton.setLineSpacing(dp(2).toFloat(), 1f)
        actions.addView(callButton, params(0, dp(104), 2f))
        sendButton = button("➤  WYŚLIJ", Color.rgb(0, 165, 80), 19f) { submit(answer.text.toString()) }
        actions.addView(sendButton, params(0, dp(64), 0.8f))
        root.addView(actions)

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(button("↻  NOWE ĆWICZENIE", Color.rgb(35, 48, 63), 16f) { reset() }, params(0, dp(48), 1f))
        bottom.addView(button("▣  RAPORT", Color.rgb(35, 48, 63), 16f) { report() }, params(0, dp(48), 1f))
        bottom.addView(button("⚙  USTAWIENIA", Color.rgb(35, 48, 63), 16f) {
            toast("Tryb instruktora. To symulator szkoleniowy — nie wykonuje prawdziwych połączeń.")
        }, params(0, dp(48), 1f))
        root.addView(bottom)
        setContentView(root)
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("pl", "PL"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts.setSpeechRate(0.84f); tts.setPitch(0.98f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {}
                override fun onError(id: String?) { runOnUiThread { toast("Błąd syntezy mowy. Sprawdź polski głos TTS w ustawieniach Androida.") } }
            })
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) { toast("Głos operatora jeszcze się uruchamia. Spróbuj za chwilę."); return }
        // One complete message per utterance; do not call stop() between operator sentences.
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
        }, "operator_${SystemClock.uptimeMillis()}")
    }

    private fun startCall() {
        active = true; startedAt = SystemClock.elapsedRealtime()
        currentQuestion = 0; score = 0; awaitingInitialReport = true
        path = emptyList()
        pathName = scenario.selectedItem?.toString() ?: "NZK + AED"
        status.text = "●  POŁĄCZENIE SZKOLENIOWE — OPERATOR SŁUCHA"
        callButton.text = "☎\nPOŁĄCZENIE\nAKTYWNE"
        currentPrompt = "Proszę powiedzieć, co się stało. Słucham."
        log.text = ""
        add("OPERATOR 112: Dzień dobry, operator numeru alarmowego 112. Proszę powiedzieć, co się stało. Słucham.")
        speak("Dzień dobry, operator numeru alarmowego 112. Proszę powiedzieć, co się stało. Słucham.")
        updateTimer()
    }

    private fun updateTimer() {
        if (!active) return
        val sec = ((SystemClock.elapsedRealtime() - startedAt) / 1000).toInt()
        timer.text = String.format(Locale.getDefault(), "%02d:%02d", sec / 60, sec % 60)
        handler.postDelayed({ updateTimer() }, 1000)
    }

    private fun submit(raw: String) {
        if (!active) { toast("Najpierw rozpocznij ćwiczenie przyciskiem 112."); return }
        if (raw.isBlank()) { toast("Powiedz lub wpisz zgłoszenie."); return }
        val a = raw.trim()
        answer.setText("")
        add("KURSANT: $a")
        if (awaitingInitialReport) {
            awaitingInitialReport = false
            choosePath(a.lowercase(Locale("pl", "PL")))
            score++
            val intro = when (pathName) {
                "NZK + AED" -> "Rozumiem. Najpierw ustalmy dokładne miejsce zdarzenia."
                "Wypadek drogowy" -> "Rozumiem. Proszę zachować ostrożność. Ustalimy miejsce i bezpieczeństwo."
                "Silne krwawienie" -> "Rozumiem. Jeśli to bezpieczne, proszę uciskać miejsce krwawienia. Ustalimy teraz szczegóły."
                "Zadławienie" -> "Rozumiem. Proszę pozostać przy poszkodowanym. Sprawdzimy, czy może oddychać i kaszleć."
                else -> "Rozumiem. Proszę oddalić się od zagrożenia. Ustalimy, czy wszyscy są bezpieczni."
            }
            add("OPERATOR 112: $intro")
            speak(intro)
            askNext()
            return
        }
        score++
        val lower = a.lowercase(Locale("pl", "PL"))
        val feedback = when {
            lower.contains("nie wiem") || lower.contains("nie jestem pew") -> "Dobrze, proszę powiedzieć tylko to, co Pan wie. Niech Pan nie ryzykuje własnego bezpieczeństwa."
            lower.contains("nie oddych") || lower.contains("brak odde") -> "Rozumiem. To bardzo ważna informacja. Proszę wykonywać moje polecenia krok po kroku."
            lower.contains("krwaw") -> "Rozumiem. Proszę utrzymywać mocny, ciągły ucisk rany, jeśli można to zrobić bezpiecznie."
            else -> "Rozumiem, dziękuję za tę informację."
        }
        add("OPERATOR 112: $feedback")
        speak(feedback)
        currentQuestion++
        if (currentQuestion >= path.size + 3) finishCall() else {
            handler.postDelayed({ if (active) askNext() }, 2800)
        }
    }

    private fun choosePath(a: String) {
        val selected = scenario.selectedItem?.toString() ?: "NZK + AED"
        pathName = when {
            a.contains("pożar") || a.contains("ogień") || a.contains("dym") || selected == "Pożar" -> "Pożar"
            a.contains("zadław") || a.contains("dławi") || a.contains("krztusi") || selected == "Zadławienie" -> "Zadławienie"
            a.contains("krwaw") || a.contains("rana") || a.contains("krew") || selected == "Silne krwawienie" -> "Silne krwawienie"
            a.contains("wypad") || a.contains("samoch") || a.contains("zderz") || selected == "Wypadek drogowy" -> "Wypadek drogowy"
            else -> "NZK + AED"
        }
        path = when (pathName) {
            "Pożar" -> firePath
            "Zadławienie" -> chokingPath
            "Silne krwawienie" -> bleedingPath
            "Wypadek drogowy" -> accidentPath
            else -> nzkPath
        }
        progress.max = path.size + 2
        progress.progress = 1
        add("SCENARIUSZ ROZPOZNANY: $pathName")
    }

    private fun askNext() {
        if (!active) return
        val q = when (currentQuestion) {
            0 -> commonLocation
            1 -> commonSafety
            2 -> commonCount
            else -> path.getOrElse(currentQuestion - 3) { "Proszę pozostać na linii i wykonywać polecenia operatora." }
        }
        currentPrompt = q
        add("OPERATOR 112: $q")
        speak(q)
        progress.progress = (currentQuestion + 2).coerceAtMost(progress.max)
    }

    private fun listen() {
        if (!active) { toast("Najpierw naciśnij duży przycisk 112."); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Rozpoznawanie mowy jest niedostępne. Możesz wpisać odpowiedź w polu tekstowym.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "●  SŁUCHAM ZGŁOSZENIA…" }
            override fun onResults(r: Bundle?) {
                val s = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                status.text = if (active) "●  POŁĄCZENIE SZKOLENIOWE" else "●  GOTOWY"
                if (s.isNotBlank()) submit(s) else toast("Nie usłyszałem odpowiedzi. Proszę spróbować ponownie.")
            }
            override fun onError(e: Int) {
                status.text = if (active) "●  POŁĄCZENIE SZKOLENIOWE" else "●  GOTOWY"
                toast("Nie udało się rozpoznać mowy. Naciśnij MÓW ponownie lub wpisz odpowiedź.")
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pl-PL")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Powiedz operatorowi, co się stało")
        }
        recognizer?.startListening(intent)
    }

    private fun finishCall() {
        active = false
        status.text = "●  ĆWICZENIE ZAKOŃCZONE"
        callButton.text = "☎\n112\nROZPOCZNIJ"
        val pct = if (path.size + 3 > 0) (score.toDouble() / (path.size + 3) * 100).toInt().coerceAtMost(100) else 0
        val msg = "Dziękuję. Proszę pozostać w bezpiecznym miejscu i wykonywać polecenia służb. To była symulacja szkoleniowa, nie prawdziwe połączenie z numerem 112."
        add("OPERATOR 112: $msg\n\nWynik orientacyjny: $pct%. Scenariusz: $pathName.")
        speak(msg)
    }

    private fun reset() {
        if (::tts.isInitialized) tts.stop()
        handler.removeCallbacksAndMessages(null)
        active = false; awaitingInitialReport = false; currentQuestion = 0; score = 0; path = emptyList()
        progress.progress = 0; timer.text = "00:00"
        status.text = "●  GOTOWY DO ĆWICZENIA"
        callButton.text = "☎\n112\nROZPOCZNIJ POŁĄCZENIE"
        log.text = "Symulator gotowy. Wybierz scenariusz i naciśnij duży przycisk 112."
    }

    private fun report() {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val text = "112 TRAINER 3.2\nRaport szkoleniowy\nData: $now\nScenariusz: $pathName\nPunkty orientacyjne: $score\n\nTo symulator szkoleniowy; nie wykonuje prawdziwych połączeń z numerem 112."
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Raport 112 Trainer"); putExtra(Intent.EXTRA_TEXT, text)
        }, "Udostępnij raport"))
    }

    private fun add(text: String) {
        log.append("\n\n$text")
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
