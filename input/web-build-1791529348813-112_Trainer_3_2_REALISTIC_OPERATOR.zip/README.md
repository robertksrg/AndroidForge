112 TRAINER 3.2 — projekt dla AndroidForge

Zmiany:
- operator po przywitaniu czeka na swobodne zgłoszenie kursanta
- scenariusz jest wybierany na podstawie wybranego typu i treści zgłoszenia
- pytania są prowadzone zależnie od scenariusza
- komunikaty TTS są wypowiadane jako kompletne wypowiedzi bez wywoływania stop() przed każdym zdaniem
- duży centralny przycisk 112 oraz większe, czytelne przyciski w układzie poziomym

Uwaga: jest to symulator szkoleniowy. Nie wykonuje prawdziwych połączeń z numerem 112.
