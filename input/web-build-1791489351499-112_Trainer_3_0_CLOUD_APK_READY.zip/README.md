# 112 TRAINER 3.0 — CLOUD BUILD

Wersja projektu przygotowana do budowania APK w chmurze.

Zawiera:
- natywny projekt Android/Kotlin,
- konfigurację Gradle,
- workflow GitHub Actions do budowania APK,
- instrukcję dla AndroidForge.

Nie wykonuje prawdziwych połączeń z numerem 112.
