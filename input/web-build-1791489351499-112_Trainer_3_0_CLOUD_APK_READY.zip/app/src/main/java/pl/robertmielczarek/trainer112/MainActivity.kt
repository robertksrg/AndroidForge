package pl.robertmielczarek.trainer112

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var progress: ProgressBar
    private lateinit var scenario: Spinner
    private lateinit var answer: EditText
    private var start = 0L
    private var step = 0
    private var score = 0
    private var active = false
    private var instructor = true
    private var lastSpeech = ""

    private val steps = listOf(
        "Proszę powiedzieć, co się stało.",
        "Proszę podać dokładne miejsce zdarzenia.",
        "Czy miejsce jest bezpieczne dla Pana i poszkodowanego?",
        "Czy poszkodowany reaguje na głos lub dotyk?",
        "Czy poszkodowany oddycha prawidłowo?",
        "Ilu jest poszkodowanych?",
        "Czy ktoś może rozpocząć uciskanie klatki piersiowej?",
        "Czy w pobliżu znajduje się AED?",
        "Proszę przynieść i włączyć AED. Czy jest już gotowe?",
        "Proszę kontynuować RKO i wykonywać polecenia AED."
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun buildUi() {
        val bg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,24,28,20)
            setBackgroundColor(Color.rgb(5,7,10))
        }

        val head = TextView(this).apply {
            text = "☎ 112 TRAINER 3.0"
            textSize = 27f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0,4,0,2)
        }
        bg.addView(head, LinearLayout.LayoutParams(-1,60))

        status = TextView(this).apply {
            text = "GOTOWY DO ĆWICZENIA"
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY)
        }
        bg.addView(status, LinearLayout.LayoutParams(-1,45))

        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timer = TextView(this).apply { text="00:00"; textSize=22f; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
        cards.addView(timer, LinearLayout.LayoutParams(0,60,1f))
        val mode = TextView(this).apply { text="● INSTRUKTOR"; textSize=15f; setTextColor(Color.rgb(90,220,130)); gravity=Gravity.CENTER }
        cards.addView(mode, LinearLayout.LayoutParams(0,60,1f))
        bg.addView(cards)

        scenario = Spinner(this)
        val names = arrayOf("NZK + AED", "Wypadek drogowy", "Silne krwawienie", "Zadławienie", "Pożar")
        scenario.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        bg.addView(scenario, LinearLayout.LayoutParams(-1,55))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = steps.size; progress.progress = 0
        bg.addView(progress, LinearLayout.LayoutParams(-1,18))

        log = TextView(this).apply {
            text = "Symulator gotowy. Wybierz scenariusz i naciśnij 112."
            textSize = 15f; setTextColor(Color.WHITE); setPadding(18,18,18,18)
            setBackgroundColor(Color.rgb(18,22,28))
        }
        val sv = ScrollView(this); sv.addView(log)
        bg.addView(sv, LinearLayout.LayoutParams(-1,0,1f))

        answer = EditText(this).apply {
            hint = "Możesz też wpisać odpowiedź…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(false)
        }
        bg.addView(answer, LinearLayout.LayoutParams(-1,58))

        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        fun btn(label:String, action:()->Unit): Button = Button(this).apply {
            text=label; textSize=13f; setOnClickListener{action()}
        }
        val call = btn("☎  ROZPOCZNIJ 112"){startCall()}
        val speak = btn("🎙 MÓW"){listen()}
        val send = btn("WYŚLIJ"){submit(answer.text.toString())}
        row.addView(call, LinearLayout.LayoutParams(0,60,1f))
        row.addView(speak, LinearLayout.LayoutParams(0,60,1f))
        row.addView(send, LinearLayout.LayoutParams(0,60,1f))
        bg.addView(row)

        val bottom = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val reset = btn("↻ NOWE"){reset()}
        val report = btn("▣ RAPORT"){report()}
        bottom.addView(reset, LinearLayout.LayoutParams(0,55,1f))
        bottom.addView(report, LinearLayout.LayoutParams(0,55,1f))
        bg.addView(bottom)

        setContentView(bg)
    }

    override fun onInit(code:Int) {
        tts.language = Locale("pl","PL")
        tts.setSpeechRate(0.93f)
    }

    private fun speak(s:String) { if(::tts.isInitialized) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "op") }

    private fun startCall() {
        if(active) return
        active=true; start=SystemClock.elapsedRealtime(); step=0; score=0
        status.text="● POŁĄCZENIE Z OPERATOREM 112 — SYMULACJA"
        add("☎ 112: Dzień dobry. Centrum Powiadamiania Ratunkowego. Proszę spokojnie odpowiadać na moje pytania.")
        speak("Dzień dobry. Centrum Powiadamiania Ratunkowego. Proszę spokojnie odpowiadać na moje pytania.")
        Handler().postDelayed({ask()}, 1500)
    }

    private fun ask() {
        if(!active) return
        val q=steps[step]
        add("👨‍💼 OPERATOR: $q")
        speak(q)
        progress.progress=step
    }

    private fun submit(raw:String) {
        if(!active || raw.isBlank()) return
        lastSpeech=raw.trim()
        answer.setText("")
        add("👤 KURSANT: $lastSpeech")
        evaluate(lastSpeech.lowercase(Locale("pl","PL")))
    }

    private fun evaluate(a:String) {
        val expected = when(step) {
            0 -> listOf("nieprzytom","leży","wypad","nie oddych")
            1 -> listOf("ulic","adres","rusz","miejsc")
            2 -> listOf("bezpiecz","tak")
            3 -> listOf("nie reag","nieprzytom")
            4 -> listOf("nie oddych","nieprawidł","brak odde")
            5 -> listOf("jed","1")
            6 -> listOf("ucisk","rko","robi")
            7 -> listOf("aed","defib")
            8 -> listOf("włącz","gotow","jest")
            9 -> listOf("ucisk","rko","aed")
            else -> emptyList()
        }
        if(expected.any{a.contains(it)}) {
            score++
            add("✓ Operator: Odpowiedź przyjęta.")
        } else {
            add("ℹ Operator: Przyjmuję informację. Jeśli czegoś brakuje, dopytam.")
        }
        if(step < steps.lastIndex) { step++; Handler().postDelayed({ask()},700) }
        else finishCall()
    }

    private fun finishCall() {
        active=false; progress.progress=steps.size
        val pct=(score.toDouble()/steps.size*100).toInt()
        val grade=when {pct>=85->"BARDZO DOBRZE"; pct>=65->"DOBRZE"; pct>=45->"DO POPRAWY"; else->"WYMAGA TRENINGU"}
        status.text="✓ ĆWICZENIE ZAKOŃCZONE — $grade"
        val msg="Zgłoszenie przyjęte. Zespół ratowniczy zostałby zadysponowany w prawdziwym zdarzeniu. To była wyłącznie symulacja szkoleniowa."
        add("👨‍💼 OPERATOR: $msg\nWynik: $score/${steps.size} — $pct% — $grade")
        speak(msg)
    }

    private fun listen() {
        if(!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Rozpoznawanie mowy niedostępne"); return }
        recognizer?.destroy()
        recognizer=SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object: RecognitionListener {
            override fun onReadyForSpeech(p:Bundle?) { status.text="🎙 SŁUCHAM KURSANTA…" }
            override fun onResults(r:Bundle?) {
                val s=r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                answer.setText(s); status.text="● GOTOWY"; if(s.isNotBlank()) submit(s)
            }
            override fun onError(e:Int){status.text="● GOTOWY"; toast("Nie udało się rozpoznać mowy")}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v:Float) {}
            override fun onBufferReceived(b:ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b:Bundle?) {}
            override fun onEvent(t:Int,b:Bundle?) {}
        })
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pl-PL")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Powiedz odpowiedź do operatora 112")
        }
        recognizer!!.startListening(i)
    }

    private fun report() {
        val now=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date())
        val txt="112 TRAINER 3.0\nRaport szkoleniowy\nData: $now\nScenariusz: ${scenario.selectedItem}\nWynik: $score/${steps.size}\n\nAplikacja jest symulatorem i nie wykonuje prawdziwych połączeń z numerem 112."
        val i=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_SUBJECT,"Raport 112 Trainer"); putExtra(Intent.EXTRA_TEXT,txt) }
        startActivity(Intent.createChooser(i,"Udostępnij raport"))
    }

    private fun reset(){active=false;step=0;score=0;progress.progress=0;status.text="GOTOWY DO ĆWICZENIA";log.text="Nowe ćwiczenie. Naciśnij 112.";answer.setText("")}
    private fun add(s:String){log.append("\n\n$s")}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private class Handler { fun postDelayed(r:()->Unit, ms:Long){android.os.Handler().postDelayed(r,ms)} }
}
