plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "pl.robertmielczarek.trainer112"; compileSdk = 35
    defaultConfig { applicationId = "pl.robertmielczarek.trainer112"; minSdk = 26; targetSdk = 35; versionCode = 30; versionName = "3.0" }
}
